function drag_move() {
    div.on('mousedown', function(e) {
        e.stopPropagation();
        if (e.button > 0) return;

        var o_x = x, o_y = y,
            s_x = e.pageX, s_y = e.pageY;

        $(document).on('mousemove.drag', function(e) {
            e.stopPropagation();
            x = Math.max(Math.min(o_x + (e.pageX - s_x), chart_w - width), 0);
            y = Math.max(Math.min(o_y + (e.pageY - s_y), chart_h - height), 0);
            div.css({ left: x, top: y });
        });

        $(document).one('mouseup', function() {
            $(document).off('mousemove.drag');
        });
        return false;
    });
}

