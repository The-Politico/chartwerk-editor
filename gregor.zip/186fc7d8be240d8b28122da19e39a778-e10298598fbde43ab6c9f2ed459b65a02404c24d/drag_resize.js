function drag_resize() {
    $('.handle', div).on('mousedown', function(e) {
        e.stopPropagation();
        if (e.button > 0) return;

        var corner = $(e.target).data('corner'),
            cv = corner.charAt(0), ch = corner.charAt(1);

        var o_x = x, o_y = y, o_w = width, o_h = height,
            s_x = e.pageX, s_y = e.pageY,
            min_h = 15, min_w = 30;

        $(document).on('mousemove.drag', function(e) {
            e.stopPropagation();

            var dx = (e.pageX - s_x),
                dy = (e.pageY - s_y);

            // dragging one of the top handles?
            if (cv == 't') {
                y = Math.min(o_y + o_h - min_h, o_y + dy);
                height = o_h + o_y - y;
            } else if (cv == 'b') {
                height = Math.max(min_h, o_h + dy);
            }
            if (cv != 'm') update_vert_align();

            if (ch == 'l') {
                x = Math.min(o_x + o_w - min_w, o_x + dx);
                width = o_w + o_x - x;
            } else if (ch == 'r') {
                width = Math.max(min_w, o_w + dx);
            }
            // x = Math.max(Math.min(o_x + , chart_w - width), 0);
            // y = Math.max(Math.min(o_y + , chart_h - height), 0);
            div.css({ left: x, top: y, height: height, width: width });
        });

        $(document).one('mouseup', function(e) {
            $(document).off('mousemove.drag');
        });
        return false;
    });
}