function activate_rect_drawing() {
    var r = { x: 0, y: 0, w: 0, h: 0 },
        chart_w = preview.width(),
        chart_h = preview.height(),
        rect = $('<div />').addClass('rect dragging').appendTo(preview).hide();

    preview.on('mousedown', function(e) {

        e.stopPropagation();
        if (e.button > 0) return;

        var o_x = e.offsetX, o_y = e.offsetY,
            p_x = e.pageX, p_y = e.pageY;

        if (preview.get(0) != e.target) return;

        rect.show();
        
        $(document).on('mousemove.drag', function(e) {
            e.stopPropagation();

            r.x = Math.max(0, Math.min(o_x + (e.pageX - p_x), o_x));
            r.y = Math.max(0, Math.min(o_y + (e.pageY - p_y), o_y));
            r.w = Math.max(e.offsetX, o_x) - r.x;
            r.h = Math.max(e.offsetY, o_y) - r.y;

            r.w = Math.min(chart_w - r.x, r.w);
            r.h = Math.min(chart_h - r.y, r.h);

            rect.css({ left: r.x, top: r.y, width: r.w, height: r.h });
        });

        $(document).one('mouseup', function(e) {
            $(document).off('mousemove.drag');
            rect.css({ width: 0, height: 0}).hide();
            if (e.target == preview.get(0) && r.w > 4 && r.h > 4) {
                annotations.push(Annotator.add(r.x, r.y, r.w, r.h, '[type here]', 'tl', 'm'));
                r.w = 0;
            } else {
                Annotator.deselect_all();
                init_help_text();
            }
        });
        return false;
    });
}